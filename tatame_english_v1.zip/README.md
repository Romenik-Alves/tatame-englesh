# Tatame English V1.0

Aplicativo web instalável (PWA) para estudar inglês de Jiu-Jitsu.

## Arquivos
- `index.html`: aplicativo com flashcards, pronúncia via voz do dispositivo, quiz, progresso e Palácio da Memória.
- `manifest.json`: configuração do aplicativo instalável.
- `sw.js`: cache para funcionamento offline depois da primeira visita.
- `icons/`: ícones do aplicativo.

## Teste rápido no computador
Abra `index.html` em um navegador moderno. A maioria das funções funciona localmente; instalação PWA e cache offline precisam de hospedagem HTTPS.

## Instalar no iPhone
1. Publique o conteúdo desta pasta em um serviço de hospedagem estática que forneça HTTPS (por exemplo, GitHub Pages, Netlify ou Cloudflare Pages).
2. Abra o endereço HTTPS no Safari do iPhone.
3. Toque em Compartilhar.
4. Escolha “Adicionar à Tela de Início”.
5. Confirme “Adicionar” e abra o ícone Tatame English.

## Áudio
O botão usa `SpeechSynthesisUtterance` com idioma en-US e a voz em inglês disponível no dispositivo. O áudio depende do navegador e das vozes instaladas; a avaliação automática da pronúncia ainda não está implementada.

## Dados e privacidade
O progresso é armazenado em `localStorage` no navegador do aparelho. Não existe servidor, login ou sincronização nesta versão. Limpar os dados do navegador pode apagar o progresso.

## Limitações desta primeira versão
- O botão “Concluir sessão” registra 20 minutos quando você o toca; não mede o tempo real.
- O quiz inclui cinco perguntas fixas.
- A pronúncia é reprodução de voz sintetizada; não grava nem avalia sua voz.
- Para uma versão de produção, recomenda-se adicionar testes, acessibilidade, política de privacidade e sincronização opcional.
